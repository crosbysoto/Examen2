const controller = {};

controller.list =  (req, res) => {
    req.getConnection((err, conn) => {
        conn.query('SELECT * FROM libros;', (err, rows) => {
            if (err) {
                res.json(err);
            }
            console.log(rows);
            res.render('libros', {
                data: rows
            });
        });
    });
};

controller.save =  (req, res) => {
    const data = req.body;

    req.getConnection((err, conn) => {
        conn.query('INSERT INTO libros set ?', [data], (err, libros) => {
            console.log(libors);
            res.redirect('/');
        });
    });
};

controller.update =  (req, res) => {
    res.send('Hello World');
};

controller.delete =  (req, res) => {
    res.send('Hello World');
};

module.exports = controller;